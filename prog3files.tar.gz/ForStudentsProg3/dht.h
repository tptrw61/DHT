#define MAX 1000
#define PUT 0
#define GET 1
#define ADD 2
#define REMOVE 3
#define END 4
#define RETVAL 5
#define ACK 6

void commandNode();

